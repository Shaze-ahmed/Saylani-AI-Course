print("Line1")
print("Line2")
