print("A")

def b():
  # Something
  return 1

def c():
  # Something
  return 2
