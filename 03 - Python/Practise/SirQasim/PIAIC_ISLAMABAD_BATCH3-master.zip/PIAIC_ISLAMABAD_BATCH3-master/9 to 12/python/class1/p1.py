print("PIAIC BAHRIA UNIVERSITY")
print("Batch3 9 to 12")
print("Pakistan")
print("Hello World")