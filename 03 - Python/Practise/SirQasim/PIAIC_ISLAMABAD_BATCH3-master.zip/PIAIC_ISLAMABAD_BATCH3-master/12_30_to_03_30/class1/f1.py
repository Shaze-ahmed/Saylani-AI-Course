print("pakistan zind bad")
print("we are pakistani")
print("Bahria University")
print("Hello world")