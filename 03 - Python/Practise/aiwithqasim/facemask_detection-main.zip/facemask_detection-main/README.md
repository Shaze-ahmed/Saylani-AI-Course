# Facemask Detection using MobileNet
![facemask detection](https://d3lkc3n5th01x7.cloudfront.net/wp-content/uploads/2020/04/01023335/MaskDetection_Banner-1-1.png)

