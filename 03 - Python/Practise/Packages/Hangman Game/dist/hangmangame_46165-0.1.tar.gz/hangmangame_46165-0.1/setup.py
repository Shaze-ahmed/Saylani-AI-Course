from setuptools import setup

setup (name='hangmangame_46165',
version='0.1',
description='This is the Hangman Game Package',
author = "Shahzad Ahmed Khan",
packages = ['hangmangame_46165'],
zip_safe=False,
install_packages = ['string','random']
)